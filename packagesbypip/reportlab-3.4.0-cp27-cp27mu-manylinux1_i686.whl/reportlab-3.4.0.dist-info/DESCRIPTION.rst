The ReportLab Toolkit. An Open Source Python library for generating PDFs and graphics.


