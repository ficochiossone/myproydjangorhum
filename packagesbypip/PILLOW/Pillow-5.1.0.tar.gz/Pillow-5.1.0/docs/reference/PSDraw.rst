.. py:module:: PIL.PSDraw
.. py:currentmodule:: PIL.PSDraw

:py:mod:`PSDraw` Module
=======================

The :py:mod:`PSDraw` module provides simple print support for Postscript
printers. You can print text, graphics and images through this module.

.. autoclass:: PIL.PSDraw.PSDraw
    :members:
