Pillow
======

Pillow is a "friendly" fork of the Python Imaging Library. The goal is to see
if any improvement can be made to the packaging situation(*) by opening up
development to the "public".

Please email: aclark@aclark.net if you'd like to help, or complain.

(*)PIL has a bad reputation for not "playing nice" with other packages. It's
kind of a long story, and you either know it by now or you don't. A better 
explanation may come later.

For PIL's README, check out PIL.txt
